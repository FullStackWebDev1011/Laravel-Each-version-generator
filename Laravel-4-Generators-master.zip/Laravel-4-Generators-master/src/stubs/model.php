<?php

class {{name}} extends Eloquent {
	
}