	public function down()
	{
	  Schema::drop('{{tableName}}');
	}