<?php

use Illuminate\Database\Migrations\Migration;

class {{name}} extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
{{up}}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
{{down}}

}