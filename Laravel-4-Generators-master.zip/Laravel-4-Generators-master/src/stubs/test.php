<?php

class {{name}} extends TestCase {
	public function test()
	{
		
	}
}